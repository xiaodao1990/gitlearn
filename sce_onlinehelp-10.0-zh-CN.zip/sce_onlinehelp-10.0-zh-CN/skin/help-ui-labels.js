
//*****************************************************************
//*****************************************************************
//***                                                           ***
//***      Copyright (c) 2011 Infor			                        ***
//***      All Rights Reserved.                                 ***
//***                                                           ***
//*****************************************************************
//*****************************************************************
var helpUiLabels = new Object();
helpUiLabels['button_back_tooltip'] = "返回"; 
helpUiLabels['button_back_label'] = "返回";
helpUiLabels['button_forward_tooltip'] = "前进一页"; 
helpUiLabels['button_forward_label'] = "前进";
helpUiLabels['button_hidenavigation_tooltip'] = "隐藏/显示导航窗格";
helpUiLabels['button_print_tooltip'] = "打印";
helpUiLabels['button_share_tooltip'] = "分享此页";
helpUiLabels['button_feedback_tooltip'] = "反馈";
helpUiLabels['email_subject_feedbackOn'] = "Feedback on"; /* Feedback on /progguide/mytopic, 8.7, en */
helpUiLabels['input_search_example_text'] = "您的搜索"; 
helpUiLabels['button_search_tooltip'] = "";
helpUiLabels['button_search_label'] = "搜索"; 